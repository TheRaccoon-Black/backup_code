# ProfilSekolah
Profil Sekolah SMK dengan menggunakan PHP Native

akun admin
username : admin
password : admin
