<?PHP error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); ?>
<?php

$koneksi = mysqli_connect('localhost', 'root', 'admin', 'db_sekolah');
date_default_timezone_set('Asia/Jakarta');

?>
