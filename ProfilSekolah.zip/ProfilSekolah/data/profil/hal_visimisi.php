<section id="profil" class="profil">
  <div class="container">
    <div class="card text-center">
      <div class="card-header">
        <h2 class="text-center">Visi Misi</h2>
      </div>
      <div class="card-body" data-aos="fade-up" data-aos-delay="100">
        <h5 class="card-title">Visi</h5>
        <p class="card-text">
          <?= $oke1['visi']; ?>
        </p>
      </div>
      <div class="card-body text-left" data-aos="fade-up" data-aos-delay="100">
        <h5 class="card-title text-center">Misi</h5>
        <p class="card-text">
          <?= $oke1['misi']; ?>
        </p>
      </div>
    </div>
  </div>
</section>