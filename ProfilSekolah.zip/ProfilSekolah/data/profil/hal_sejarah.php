<section id="profil" class="profil">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2 class="text-center">Sejarah Sekolah</h2>
            </div>
            <div class="card-body" data-aos="fade-up" data-aos-delay="100">
                <p class="card-text">
                    <?= $oke1['sejarah_sekolah']; ?>
                </p>
            </div>
        </div>
    </div>
</section>