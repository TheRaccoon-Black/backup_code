<?php 
include "db.php";

$kontak = mysqli_query($conn, "select * from tb_admin where admin_id = 1");
$a = mysqli_fetch_object($kontak);


$search = isset($_GET['search']) ? $_GET['search'] : '';
$kat = isset($_GET['kat']) ? $_GET['kat'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
    <title>Produk | Aduan </title>
</head>
<body>
  <header>
    <div class="container">
    <h1><a href="index.php">Aduanku.com</a></h1>
    <ul>
        <li><a href="aduan.php">Pengaduan</a></li>
        <li><a href="index.php">Dashbord</a></li>
    </ul>
    </div>
  </header>
  <div class="search">
    <div class="container">
        <form action="aduan.php">
            <input type="text" class="cari" name="search" placeholder="cari aduan" value="<?php echo $search ?>">
            <input type="hidden" name="kat" value="<?php echo $kat ?>">
            <input type="submit"  class="btn" name="submit" value="Cari" style="margin-top:5px;">
        </form>
    </div>
  </div>  
  <div class="section">
    <div class="container">
    <div class="judul1"> Aduan </div>
      <div class="box">
            <?php 
            error_reporting(0);
            if($search!='' || $kat!=''){
                $where = "AND pengadu_nama like '%".$search."%' AND kategori_id like '%".$kat."%'"; 
            }

            $aduan = mysqli_query($conn, "select * from tb_produk where aduan_status = 1 $where order by aduan_id desc ");
            if(mysqli_num_rows($aduan)>0){
              while($p = mysqli_fetch_array($aduan)){
            ?>
            <a href="detail-aduan.php?id=<?php echo $p['aduan_id'] ?>">
            <div class="col-4">
              <img src="gambar/kategori.png" style="width:100px;height: 100px;">
              <p class="nama"><?php echo $p['pengadu_nama'] ?></p>
              <p class="nama"><?php echo $p['aduan_desk'] ?></p>
            </div>
              </a>
            <?php }}else{ ?>
              <p>aduan tidak ada</p>
              <?php } ?>
      </div>
    </div>
  </div>
  <div class="footer">
    <div class="container">
      <h4>Alamat</h4>
      <p><?php echo $a->admin_alamat?></p>
      <h4>Email</h4>
      <p><?php echo $a->admin_email?></p>
      <h4>Telepon</h4>
      <p><?php echo $a->admin_telp?></p>
      <small>Copyright &copy; 2023 - Aduanku.com</small>
    </div>
  </div>
</body>
</html>?>