<?php
session_start();
include "db.php";
if ($_SESSION['status_login'] != true) {
  echo '<script>window.location="login.php"</script>';
}
$produk = mysqli_query($conn, "select * from tb_produk where aduan_id = '" . $_GET['id'] . "'");
if (mysqli_num_rows($produk) == 0) {
  header("location: data-produk.php");
}
$p = mysqli_fetch_object($produk);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
  <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
  <title>Edit Aduan | Aduanku.com </title>
</head>

<body>
  <header>
    <div class="container">
      <h1><a href="">Aduanku</a></h1>
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="profil.php">Profil</a></li>
        <li><a href="data-kategori.php">Data Kategori</a></li>
        <li><a href="data-produk.php">Data Aduan</a></li>
        <li><a href="keluar.php">Log Out</a></li>
      </ul>
    </div>
  </header>
  <div class="section">
    <div class="container">
      <h1>Edit aduan</h1>
      <div class="box">
        <form action="" method="POST" enctype="multipart/form-data">
          <select class="input-control" name="kategori" required>
            <option value="">---Pilih---</option>
            <?php
            $kategori = mysqli_query($conn, "select * from tb_kategori order by kategori_id desc");
            while ($r = mysqli_fetch_array($kategori)) {
              ?>
              <option value="<?php echo $r['kategori_id'] ?>" <?php echo ($r['kategori_id'] == $p->kategori_id) ? 'selected' : ''; ?>><?php echo $r['kategori_nama'] ?></option>
            <?php } ?>
          </select>
          <input type="text" name="nama" placeholder="nama pengadu" class="input-control"
            value="<?php echo $p->pengadu_nama ?>" required>
          <textarea name="isi" placeholder="Deskripsi"
            class="input-control"><?php echo $p->aduan_desk ?></textarea>
          <select class="input-control" name="status">
            <option value="">---Pilih---</option>
            <option value="1" <?php echo ($p->aduan_status == 1) ? 'selected' : ''; ?>>Terima</option>
            <option value="0" <?php echo ($p->aduan_status == 2) ? 'selected' : ''; ?>>Tolak</option>
          </select>

          <input type="submit" name="submit" value="Submit" class="btn">
        </form>
        <?php
        if (isset($_POST['submit'])) {
          $kategori = $_POST["kategori"];
          $nama = $_POST["nama"];
          $isi = $_POST["isi"];
          $status = $_POST["status"];
          $update = mysqli_query($conn, "update tb_produk set
                kategori_id ='" . $kategori . "',
                pengadu_nama = '" . $nama . "',
                aduan_desk = '" . $isi . "',
                aduan_status = '" . $status . "'
                where aduan_id = '" . $p->produk_id . "';");
          if ($update) {
            echo "<script>alert('Edit data berhasil dilakukan')</script>";
            header("Location: data-aduan.php");
          } else {
            echo "gagal" . mysqli_error($conn);
          }
        }
        ?>


      </div>

    </div>
  </div>
  <footer>
    <div class="container">
      <small>Copyright &copy; 2023 - aduanku</small>
    </div>
  </footer>
  <script>
    CKEDITOR.replace('isi')
  </script>
</body>

</html>