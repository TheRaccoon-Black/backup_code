<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
    <title>login | Aduanku.com </title>
</head>

<body style="height: 100vh;justify-content: center;align-items: center;background-image: url('gambar/ikn2.jpeg');" >
<div class="" style="display: flex;justify-content:space-around;align-items: center; margin-top: 30px;">
    <div class="" style="margin-right: 10px;">
        <img src="gambar/download.jpeg">
    </div>
    <div style="margin-right: 10px;">
        <h1 style="font-size:50px; background-color:grey; padding:10px;border-radius: 10px;">Aduanku.com</h1>
    </div>
    <div class="">
        <img src="gambar/ipdnbaru.jpeg">
    </div>
</div>
<center><div>
    <h1 style="margin:40px;background-color: grey;width: 500px;padding: 20px;border-radius: 10px;font-weight: bolder;">MENUJU INDONESIA MAJU</h1>
</div></center><center>
  <div class="" style="border-radius:10px; width: 300px;
min-height: 200px;border: 1px solid #ccc;background-color: #fff;padding: 15px;box-sizing: border-box;">
        <h2 style="text-align: center;margin-bottom: 15px;">Login</h2>
        <form action="" method="POST">
            <input type="text" name="user" placeholder="Username" class="input-control">
            <input type="password" name="pass" placeholder="password" class="input-control">
            <input type="submit" name="submit" value="Login" class="btn">
        </form>
        <?php
        if (isset($_POST['submit'])) {
            include "db.php";
            session_start();
            $user = $_POST['user'];
            $pass = $_POST['pass'];

            $cek = mysqli_query($conn, "select * from tb_admin where username = '" . $user . "' and password = '" . $pass . "'");
            if (mysqli_num_rows($cek) > 0) {
                $d = mysqli_fetch_object($cek);
                $_SESSION['status_login'] = true;
                $_SESSION['a_global'] = $d;
                $_SESSION['id'] = $d->admin_id;
                echo "<script>alert('login berhasil')</script>";
                header("Location: dashboard.php");
            } else {
                echo "<script type='text/javascript'>alert('username atau password salah!!!')</script>";
            }
        }
        ?>
    </div>
</center>
</body>

</html>