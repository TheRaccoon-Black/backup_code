-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 02, 2023 at 05:29 PM
-- Server version: 8.0.35-0ubuntu0.22.04.1
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengaduan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` int NOT NULL,
  `admin_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `admin_telp` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `admin_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `admin_alamat` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_alamat`) VALUES
(1, 'Dinas Pariwisata Provinsi Bengkulu', 'Admin', 'admin', '+6285555566', 'IKN@gmail.com', 'Ibu Kota Negara'),
(2, 'triana', 'admin2', 'admin', '122222222', 'fsdfads@gmail.com', 'qwertyuiopasdfghjklzxcvbnm wertj');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `kategori_id` int NOT NULL,
  `kategori_nama` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`kategori_id`, `kategori_nama`) VALUES
(19, 'Pelayanan Buruk'),
(20, 'Insfrastruktur Rusak'),
(21, 'Keamanan'),
(22, 'Kesehatan'),
(23, 'Lingkungan');

-- --------------------------------------------------------

--
-- Table structure for table `tb_produk`
--

CREATE TABLE `tb_produk` (
  `aduan_id` int NOT NULL,
  `kategori_id` int NOT NULL,
  `pengadu_nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `aduan_desk` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `aduan_status` tinyint(1) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_produk`
--

INSERT INTO `tb_produk` (`aduan_id`, `kategori_id`, `pengadu_nama`, `aduan_desk`, `aduan_status`, `tanggal`) VALUES
(32, 16, 'alif', 'tidak ada fasilitas ibadah di lokasi saya\r\n\r\n', 1, '2023-05-27 17:00:00'),
(34, 18, 'ojik', '<p>susah mencari tempat ibadah</p>\r\n\r\n<p>&nbsp;</p>\r\n', 1, '2023-12-01 17:00:00'),
(35, 18, 'ariq', '<p>apapun itu hanya tes saja</p>\r\n', 1, '2023-12-01 17:00:00'),
(36, 19, 'alif', '<p>Saya sangat kecewa dengan pelayanan yang diberikan oleh instansi terkait. Petugas tidak ramah dan lambat dalam menanggapi permohonan saya</p>\r\n', 1, '2023-12-01 17:00:00'),
(37, 20, 'eqiq', '<p>Tolong segera perbaiki jalan raya di daerah saya. Lubang-lubang di jalan tersebut membuat kondisi sangat berbahaya bagi pengguna jalan.</p>\r\n', 1, '2023-12-01 17:00:00'),
(38, 21, 'andi', '<p>saya merasa khawatir dengan tingkat keamanan di lingkungan saya. Peningkatan patroli keamanan dan pemasangan lampu jalan dapat membuat warga merasa lebih aman.</p>\r\n', 1, '2023-12-01 17:00:00'),
(39, 22, 'indah', '<p>Fasilitas kesehatan di wilayah ini perlu ditingkatkan. Banyak warga yang kesulitan mendapatkan pelayanan kesehatan yang memadai.</p>\r\n', 1, '2023-12-01 17:00:00'),
(40, 23, 'denis', '<p>&quot;Fasilitas kesehatan di wilayah ini perlu ditingkatkan. Banyak warga yang kesulitan mendapatkan pelayanan kesehatan yang memadai.&quot;</p>\r\n', 1, '2023-12-01 17:00:00'),
(41, 19, 'ari', '<p>Antrian panjang dan pelayanan yang lambat membuat proses administrasi menjadi sangat tidak efisien.</p>\r\n', 1, '2023-12-01 17:00:00'),
(42, 20, 'ira', '<p>Jalan di sekitar kompleks perumahan rusak parah, menyebabkan kendaraan sering mengalami kerusakan.</p>\r\n', 1, '2023-12-01 17:00:00'),
(43, 21, 'Doni', '<p>Kurangnya pencahayaan di beberapa gang membuat lingkungan menjadi rawan kejahatan.</p>\r\n', 1, '2023-12-01 17:00:00'),
(44, 22, 'doni', '<p>Ketersediaan obat-obatan di puskesmas perlu diperhatikan agar warga dapat dengan mudah mengaksesnya.</p>\r\n', 1, '2023-12-01 17:00:00'),
(45, 23, 'aji', '<p>Sungai di wilayah ini tercemar, perlu adanya upaya untuk membersihkan dan menjaga kelestarian alam.</p>\r\n', 1, '2023-12-01 17:00:00'),
(46, 21, 'redo', '<p>&quot;Kurangnya pencahayaan di beberapa gang membuat lingkungan menjadi rawan kejahatan.&quot;</p>\r\n', 1, '2023-12-01 17:00:00'),
(47, 21, 'ina', '<p>Tingkat kejahatan di wilayah ini meningkat. Penambahan patroli keamanan di malam hari sangat dibutuhkan.</p>\r\n', 1, '2023-12-01 17:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`aduan_id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `kategori_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tb_produk`
--
ALTER TABLE `tb_produk`
  MODIFY `aduan_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
