<?php
include "db.php";

$kontak = mysqli_query($conn, "select * from tb_admin where admin_id = 1");
$a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Ibu kota Negara | Aduanku.com</title>
    <style >
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    height: auto;
}

header {
    background-color: ##37b916;
    color: white;
    padding: 10px;
    text-align: center;
}

nav {
    margin-top: 10px;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

section {
    margin: 20px;
}

h2 {
    color: #3498db;
}

.visi,
.misi {
    margin-bottom: 20px;
}

footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

    </style>
</head>

<body>
    <header>
        <h1>Pemerintah Nasional</h1>
        <nav>
            <ul>
                        <li><a href="aduan.php">Pengaduan</a></li>
        <li><a href="profilinstansi.php">Profil</a></li>
            </ul>
        </nav>
    </header>

    <section id="home">
        <h2>Selamat Datang di Profil IKN</h2>
        
    </section>

    <section id="visi-misi">
        <h2>Visi Misi</h2>
        <div class="visi">
            <h3>Visi</h3>
            <p>Menjadi Ibu kota negara yang Unggul, Sejahtera, dan Berdaya Saing</p>
        </div>
        <div class="misi">
            <h3>Misi</h3>
            <ol>
                <li>Meningkatkan kualitas sumber daya manusia.</li><br>
                <li>Memperkuat infrastruktur untuk mendukung pembangunan daerah.</li><br>
                <li>Meningkatkan perekonomian dan kesejahteraan masyarakat.</li>
            </ol>
        </div>
    </section>
    <br>

    <section id="program-unggulan">
        <h2>Program Unggulan</h2>
        <ul>
            <li>Program 1: Pembangunan Infrastruktur</li><br>
            <li>Program 2: Pendidikan Unggul</li><br>
            <li>Program 3: Kesehatan Masyarakat</li><br>
        </ul>
    </section>

    <section id="kontak">
        
        <h2>Kontak</h2>
        <p>Alamat: <?php echo $a->admin_alamat ?></p>
        <p>Email: <?php echo $a->admin_email ?></p>
        <p>Telepon: <?php echo $a->admin_telp ?></p>
    </section>

    <footer width="20px">
        <p>&copy; Powered by Aduanku.com</p>
    </footer>
</body>

</html>
